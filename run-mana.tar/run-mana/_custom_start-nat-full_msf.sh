#!/bin/bash

msfconsole -r /etc/mana-toolkit/karmetasploit.rc
