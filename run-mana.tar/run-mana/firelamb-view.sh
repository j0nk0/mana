#!/bin/sh

/usr/share/mana-toolkit/firelamb/firelamb.py -l -t /var/lib/mana-toolkit/sslsplit/
